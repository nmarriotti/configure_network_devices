$vcenter_pass=
